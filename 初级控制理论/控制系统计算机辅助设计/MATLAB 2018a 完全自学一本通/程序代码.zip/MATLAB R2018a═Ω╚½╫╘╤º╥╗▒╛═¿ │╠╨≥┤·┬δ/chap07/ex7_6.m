syms a b c d e f g h;
A=sym('[a,b;c,d]')
A =
	 [ a, b]
	 [ c, d]
B=sym('[e,f;g,h]')
B =
	 [ e, f]
	 [ g, h]
R=A\B
