sym x,y;
f1=sym('1/(sin(x)+cos(x))')
f1 =
	1/(cos(x) + sin(x))
finverse(f1)
