syms x;
f1=sym((cos(x)+sin(x)-x)/x)
f1 =
	 (cos(x) - x + sin(x))/x
limit(f,x,inf)
