sym x;
f1=sym('(x-1)^3')
f 1=
	 (x - 1)^3
collect(f1)
