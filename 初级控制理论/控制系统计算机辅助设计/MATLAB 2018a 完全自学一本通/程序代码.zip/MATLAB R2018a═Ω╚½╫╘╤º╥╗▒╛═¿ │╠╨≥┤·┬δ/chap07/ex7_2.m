x=sym('x')

y=sym('x')

z1=sym('z1','real')

z2=sym('z2','positive')