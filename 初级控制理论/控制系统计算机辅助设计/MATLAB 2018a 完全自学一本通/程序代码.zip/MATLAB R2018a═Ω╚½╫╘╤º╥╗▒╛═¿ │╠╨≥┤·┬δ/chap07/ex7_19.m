syms x y;
f1=sym('2*x^2-7*x*y-22*y^2-5*x+35*y-3')
f1 =
	2*x^2 - 7*x*y - 5*x - 22*y^2 + 35*y �C 3
factor(f1)
