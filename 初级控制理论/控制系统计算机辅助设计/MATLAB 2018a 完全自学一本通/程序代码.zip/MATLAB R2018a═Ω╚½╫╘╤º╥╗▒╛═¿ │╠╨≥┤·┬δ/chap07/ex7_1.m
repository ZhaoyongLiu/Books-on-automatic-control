r=sym(2/3)

f=sym(2/3,'f')  

d=sym(2/3,'d')

e=sym(2/3,'e')