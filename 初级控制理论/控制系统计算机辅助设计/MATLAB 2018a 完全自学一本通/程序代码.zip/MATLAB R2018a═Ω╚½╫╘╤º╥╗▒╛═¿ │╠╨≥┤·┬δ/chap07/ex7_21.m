syms x y;
f=sym('x^2+x*y+y^2')
f =
	x^2 + x*y + y^2
x=2
subs(f)
