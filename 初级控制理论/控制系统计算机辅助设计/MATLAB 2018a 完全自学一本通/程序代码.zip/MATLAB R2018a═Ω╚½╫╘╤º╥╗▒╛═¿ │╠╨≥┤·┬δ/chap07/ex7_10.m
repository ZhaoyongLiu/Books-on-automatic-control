a=pi;
b='pi';
c=sym('3.1415926');
d=sym('d');
syms e;
classa=class(a)
classb=class(b)
classc=class(c)
classd=class(d)
classe=class(e)
