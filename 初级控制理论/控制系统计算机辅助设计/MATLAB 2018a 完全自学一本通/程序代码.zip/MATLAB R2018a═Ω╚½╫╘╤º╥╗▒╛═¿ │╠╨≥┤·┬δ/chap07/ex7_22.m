syms x a;
f=sym('2*x^2+a*x+3+x^-1')
s=solve(f)
