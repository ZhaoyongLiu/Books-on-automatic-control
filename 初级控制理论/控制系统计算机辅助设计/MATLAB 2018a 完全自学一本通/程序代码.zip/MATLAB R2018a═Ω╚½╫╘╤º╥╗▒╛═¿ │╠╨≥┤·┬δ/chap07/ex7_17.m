syms x y;
f1=sym('(x-1)^2*(y-1)')
f1 =
	 (x - 1)^2*(y - 1)
expand(f1)
