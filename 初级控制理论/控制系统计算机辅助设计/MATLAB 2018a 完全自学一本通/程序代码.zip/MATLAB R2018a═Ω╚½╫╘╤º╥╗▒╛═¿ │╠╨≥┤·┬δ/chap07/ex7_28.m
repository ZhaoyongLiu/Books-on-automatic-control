syms x y n;
f1=sym('x^2')
f1 =
	x^2
symsum(f1,0,n-1)
