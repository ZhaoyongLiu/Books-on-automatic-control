syms x;
R=isa(x,'sym')
