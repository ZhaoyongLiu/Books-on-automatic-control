function y=myt(x)
global a;
a=a+9;
y=cos(x);
