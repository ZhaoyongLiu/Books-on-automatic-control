function [y,x]=mythee(x)
x=x+2;
y=x.^2;
