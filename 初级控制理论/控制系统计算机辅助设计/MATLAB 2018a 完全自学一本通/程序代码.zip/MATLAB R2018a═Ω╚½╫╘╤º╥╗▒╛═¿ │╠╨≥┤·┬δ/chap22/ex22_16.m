A=ones(1,3)
B=[1 7 7 5]
C=conv(A,B)
