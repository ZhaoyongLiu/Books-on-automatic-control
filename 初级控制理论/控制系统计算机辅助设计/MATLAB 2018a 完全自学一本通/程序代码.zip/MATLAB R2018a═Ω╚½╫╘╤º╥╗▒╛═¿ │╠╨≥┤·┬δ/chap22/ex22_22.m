L=64;
wvtool(hamming(L))
