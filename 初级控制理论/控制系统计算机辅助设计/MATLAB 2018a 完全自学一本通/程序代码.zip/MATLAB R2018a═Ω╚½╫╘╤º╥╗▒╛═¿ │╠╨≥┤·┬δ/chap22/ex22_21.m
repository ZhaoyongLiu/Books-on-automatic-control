w1= bartlett(7);
w2= bartlett(8);
wvtool(w1);
wvtool(w2);
