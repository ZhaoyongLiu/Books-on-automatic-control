x = normrnd(10,1,25,1);
normplot(x)
figure;
normplot([x,1.5*x])
