function mainrank
mat_feat('rank')
