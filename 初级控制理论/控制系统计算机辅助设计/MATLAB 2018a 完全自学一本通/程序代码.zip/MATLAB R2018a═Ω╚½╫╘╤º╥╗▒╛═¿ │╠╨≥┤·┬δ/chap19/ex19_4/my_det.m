function d=my_det(A)
d=det(A);
