clear all
clc
 [names, levelnum, x, y, answer]  = textread('textread.txt', ...
'%9s level%s %f %2d %3s', 1)
