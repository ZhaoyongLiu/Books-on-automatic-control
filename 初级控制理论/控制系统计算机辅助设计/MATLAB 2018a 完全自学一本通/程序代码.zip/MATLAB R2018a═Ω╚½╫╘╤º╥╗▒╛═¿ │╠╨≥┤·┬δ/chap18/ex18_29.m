type table.txt
fid=fopen('table.txt','r');
title=fscanf(fid,'%s');
status=fclose(fid);
title
fid=fopen('table.txt','r')
data=fscanf(fid,'%f')



