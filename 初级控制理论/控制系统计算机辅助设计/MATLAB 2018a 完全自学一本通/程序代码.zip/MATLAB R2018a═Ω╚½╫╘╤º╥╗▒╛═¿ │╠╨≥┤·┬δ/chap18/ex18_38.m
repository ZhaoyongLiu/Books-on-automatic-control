clear all
clc
[names, types, x, y, answer] = textread('textread.txt', ...
'%s %s %f %d %s', 1)
