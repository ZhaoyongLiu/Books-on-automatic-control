clear all
clc
[names,types, y, answer] = textread('textread.txt', ...
'%9s %6s %*f %2d %3s', 1)
