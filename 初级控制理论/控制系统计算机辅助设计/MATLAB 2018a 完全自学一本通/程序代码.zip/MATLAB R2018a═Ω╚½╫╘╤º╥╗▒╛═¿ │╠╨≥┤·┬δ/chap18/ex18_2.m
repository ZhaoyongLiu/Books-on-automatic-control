clear all
d1=dir
d2=ls
