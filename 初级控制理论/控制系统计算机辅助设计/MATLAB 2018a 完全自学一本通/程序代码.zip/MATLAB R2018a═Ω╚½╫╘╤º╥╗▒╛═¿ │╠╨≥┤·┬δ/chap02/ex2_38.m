A = eye(5,3)

ndims(A)

length(A)

[m,n] = size(A)