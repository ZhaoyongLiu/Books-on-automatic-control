A = []; B = 1:4; C = [1:4; 5:8];
S1= size(A), S2= size(B), S3= length(B), S4= size(C), S5= length(C), S6= numel(C)
