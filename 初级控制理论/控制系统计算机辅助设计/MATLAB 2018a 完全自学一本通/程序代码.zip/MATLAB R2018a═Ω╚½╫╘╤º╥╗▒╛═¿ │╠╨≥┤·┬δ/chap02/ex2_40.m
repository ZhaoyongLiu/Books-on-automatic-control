A = []; B = 5; C = 1:3; D = magic(2); E(:,:,2) = [1 2; 3 4];
Ndims = [ndims(A) ndims(B) ndims(C) ndims(D) ndims(E)]
