Matrix = magic( 3 ); IND = sub2ind( size( Matrix ), 2,3),
    [I J]= ind2sub( size( Matrix ), 7)
