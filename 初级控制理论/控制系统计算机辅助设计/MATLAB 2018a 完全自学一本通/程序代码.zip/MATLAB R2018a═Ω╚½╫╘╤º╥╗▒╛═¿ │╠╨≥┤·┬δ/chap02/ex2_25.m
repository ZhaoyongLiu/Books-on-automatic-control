keys(schedulemap)
values(schedulemap)
