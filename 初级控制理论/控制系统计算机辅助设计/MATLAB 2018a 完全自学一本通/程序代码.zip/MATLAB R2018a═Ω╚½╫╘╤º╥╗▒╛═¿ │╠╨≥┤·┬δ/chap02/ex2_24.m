schedulemap = containers.Map({'Monday','Tuesday','Wednesday','Thursday',
'Friday'},
{'Maths','Chinese','History','Geography','Biology'})
