A=1:9
TrueorFalse = ~( A>4 )
