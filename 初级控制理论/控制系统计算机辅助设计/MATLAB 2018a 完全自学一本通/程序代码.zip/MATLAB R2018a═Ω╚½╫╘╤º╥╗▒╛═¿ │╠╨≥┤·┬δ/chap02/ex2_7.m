String ='Every good boy does fun.';
U=abs (String)
