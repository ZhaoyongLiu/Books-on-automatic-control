String ='Every good boy does fun.';
size(String)
