String =' Peter Piper picked a peck of pickled peppers. ' ;
String(1:12) =' Helen Smith'
