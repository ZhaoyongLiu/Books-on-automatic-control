A='top';  B=''; C='Bottom';
sABC=strvcat(A,B,C),cABC=char(A,B,C),size=[size(sABC);size(cABC)]
