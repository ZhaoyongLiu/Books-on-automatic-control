function f = ex12_10(x)
f = 3*x(1)^2 + 2*x(1)*x(2) + x(2)^2;
