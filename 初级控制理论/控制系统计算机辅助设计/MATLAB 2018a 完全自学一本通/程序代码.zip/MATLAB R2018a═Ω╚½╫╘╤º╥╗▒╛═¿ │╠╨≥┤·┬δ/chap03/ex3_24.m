C=toeplitz(2:5,2:2:8);
C=C'
