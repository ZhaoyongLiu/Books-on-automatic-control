clear all
format short;
A=logspace(1,2,20)
B=logspace(1,2,10)
