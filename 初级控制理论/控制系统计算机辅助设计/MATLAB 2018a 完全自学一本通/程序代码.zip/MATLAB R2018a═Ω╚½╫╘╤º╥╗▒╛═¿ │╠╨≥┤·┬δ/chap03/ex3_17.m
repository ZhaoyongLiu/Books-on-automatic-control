clear all
B=randn(3)
C=randn([3,4])
D=randn(size(C))
