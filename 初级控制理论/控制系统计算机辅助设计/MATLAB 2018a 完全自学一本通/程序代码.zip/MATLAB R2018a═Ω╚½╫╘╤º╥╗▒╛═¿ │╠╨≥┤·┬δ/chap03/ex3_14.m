A=hilb(3)
B=invhilb(3)