clear all
a=ones(3,4)
b=zeros(3,4)
c=[a;b]
