A = magic(20);
A(9:20,:) = [];
figure; plot(A)
