x = -pi/2:0.01:pi/2;
 y = x + sin(x) + exp(x);
