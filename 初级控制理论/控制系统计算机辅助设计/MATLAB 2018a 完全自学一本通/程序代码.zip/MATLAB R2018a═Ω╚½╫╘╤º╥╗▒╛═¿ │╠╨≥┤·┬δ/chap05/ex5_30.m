figure
surf(X,Y,Z,'FaceColor','red','EdgeColor','none');
camlight left; lighting phong
view(-15,65)
