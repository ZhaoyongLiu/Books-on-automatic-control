sum = 0;
for i = 1:1:100
    sum = sum + i;
end
sum
