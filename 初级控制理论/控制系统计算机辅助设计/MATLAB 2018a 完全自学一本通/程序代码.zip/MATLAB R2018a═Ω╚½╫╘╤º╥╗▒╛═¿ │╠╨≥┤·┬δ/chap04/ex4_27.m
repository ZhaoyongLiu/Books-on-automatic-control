 assignin('base', 'Num', 0)
 Num
Array = 1:10;
 assignin('base', 'Array(4:7)', Num)
