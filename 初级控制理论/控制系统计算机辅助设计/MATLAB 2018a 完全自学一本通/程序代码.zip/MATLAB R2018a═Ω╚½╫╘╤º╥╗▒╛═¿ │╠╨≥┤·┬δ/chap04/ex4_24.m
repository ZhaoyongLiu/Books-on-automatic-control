inmem
ans = 
    'MATLABrc'
    'pathdef'
    'userpath'
    'ispc'
    'filesep'
    'pwd'
    'usejava'
    'initializeMATLABRoot'
    'opaque.char'
'hgrc'
��
    'helpProcess.getDemoTopic'
    'helpProcess.displayHelp'
