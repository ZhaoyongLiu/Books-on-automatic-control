[x,y,z]=sphere;
I= imread('peppers.png');
warp(x,y,z,I);
