[X,map] = imread('trees.tif');
gmap = rgb2gray(map);
figure;imshow(X,map)
figure;imshow(X,gmap);
