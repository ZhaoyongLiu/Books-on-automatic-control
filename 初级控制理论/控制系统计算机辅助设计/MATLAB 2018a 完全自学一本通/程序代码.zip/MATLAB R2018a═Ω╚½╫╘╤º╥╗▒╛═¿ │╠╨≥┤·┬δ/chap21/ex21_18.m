h = fspecial('gaussian')
freqz2(h)
