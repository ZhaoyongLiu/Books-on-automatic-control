imshow trees.tif
vals = impixel
