imshow peppers.png
improfile
