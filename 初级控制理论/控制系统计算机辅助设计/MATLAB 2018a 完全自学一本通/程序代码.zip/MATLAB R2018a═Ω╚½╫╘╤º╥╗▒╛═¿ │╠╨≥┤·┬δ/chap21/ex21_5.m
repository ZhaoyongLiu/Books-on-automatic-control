I = imread('moon.tif');
imshow(I)
colorbar
I1 = imread('peppers.png');
figure
imshow(I1)
colorbar
