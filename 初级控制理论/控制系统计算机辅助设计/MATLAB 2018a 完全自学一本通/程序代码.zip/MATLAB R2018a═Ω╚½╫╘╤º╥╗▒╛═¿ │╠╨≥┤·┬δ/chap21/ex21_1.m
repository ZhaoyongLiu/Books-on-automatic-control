A= magic(5);
X = [19.5 23.5];
y = [8.0 12.0];
image(A,'XData',X,'YData',y), axis image, colormap(jet(25))
