I = imread('cameraman.tif');
figure;
subplot(121);imshow(I);
subplot(122);h = imshow(I,[0 80]);
