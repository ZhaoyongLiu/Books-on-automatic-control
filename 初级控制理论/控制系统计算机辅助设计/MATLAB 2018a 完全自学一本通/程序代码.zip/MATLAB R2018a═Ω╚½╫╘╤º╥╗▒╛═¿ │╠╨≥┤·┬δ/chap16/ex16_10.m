Z = peaks; 
plot(1:49,Z(4:7,:))						%�ο�ͼ20-11��a��
close
set(0,'DefaultAxesColorOrder',[0 0 0],...
      'DefaultAxesLineStyleOrder','-|--|:|-.')
plot(1:49,Z(4:7,:))						%�ο�ͼ20-11��b��
set(0,'DefaultAxesColorOrder','remove',...
      'DefaultAxesLineStyleOrder','remove')
