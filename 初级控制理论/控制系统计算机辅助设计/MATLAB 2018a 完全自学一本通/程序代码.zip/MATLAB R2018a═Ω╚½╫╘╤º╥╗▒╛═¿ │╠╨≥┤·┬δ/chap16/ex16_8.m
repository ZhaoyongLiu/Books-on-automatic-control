figure('Position',[1 1 400 300],'Units','inches')
set(gcf,'Units','pixels')
get(gcf,'Position')
