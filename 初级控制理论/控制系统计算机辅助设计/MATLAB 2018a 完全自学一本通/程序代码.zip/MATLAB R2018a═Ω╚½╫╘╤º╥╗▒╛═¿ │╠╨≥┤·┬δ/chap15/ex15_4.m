>>x = [0;0;0];
>>u = 0;
>>y = [3;3];
>>ix = [];
>>iu = [];
>>iy = [1;2];
>>[x,u,y,dx] = trim('exb',x,u,y,ix,iu,iy)