if percent==100
	{percent=0;
	sec=sec+1;}
else if sec==60
		{sec=0;
		min=min+1;}
	end
end
